import myParser
import os
import random
import instuction_set

# 有报错是因为对于跳转的分支未能继续记录寄存器值了

def random_insert_list(list1=[], list2=[]):
    for i in list2:
        list1.insert(random.randint(0, len(list1)), i)


def ins_gener(x, config, reg, mem):
    op = random.randint(0, x)
    if op == 0:
        reg, ins = instuction_set.add(reg)
    elif op == 1:
        reg, ins = instuction_set.sub(reg)
    elif op == 2:
        config, reg, ins = instuction_set.ori(config, reg)
    elif op == 3:
        reg, mem, ins = instuction_set.lw(reg, mem)
    elif op == 4:
        reg, mem, ins = instuction_set.sw(reg, mem)
    elif op == 5:
        config, reg, ins = instuction_set.lui(config, reg)
    elif op == 6:
        ins = instuction_set.nop()
    elif op == 7:
        config, ins = instuction_set.beq(config)
    elif op == 8:
        config, ins = instuction_set.jal(config)
    elif op == 9:
        config, reg, ins = instuction_set.jr(config, reg)
    return ins, config, reg, mem


def run():
    config = myParser.prepare_parser()
    config['label_num'] = 0
    config['jump_num'] = 0

    print("---------------------------------------------------------------------------------------------"
          "-----------------------------------------------------------")
    print("The config of TestSuit:")
    print(config)
    print("---------------------------------------------------------------------------------------------"
          "-----------------------------------------------------------")
    
    init_asm = []
    # use reg to track 32 register
    reg = {}
    mem = {}
    reg[0] = 0

    for i in range(12278):
        mem[i] = 0
    if config['init']:
        for i in range(32):
            hi = random.randint(0, 65536)
            lo = random.randint(0, 65536)
            init_asm.append("lui $%d, 0x%x\n" % (i, hi))
            init_asm.append("ori $%d, $%d, 0x%x\n" % (i, i, lo))
            if i != 0:
                reg[i] = (hi << 16) | lo
            # print("%x, %x, %x" % (reg[i], hi, lo))
    else:
        for i in range(32):
            reg[i] = 0

    # if not config['init']:  # if didn't random init, follow MARS initial settings
    #     reg[28] = 0x0000_1800
    #     reg[29] = 0x0000_2ffc

    # print(reg)
    # print(mem)
    file_name = 'code.asm'
    with open(file_name, "w") as file:
        buffer = []
        labels = []
        print(config['bound'])
        for j in range(config['test_size']):
            if j < 50:
                ins, config, reg, mem = ins_gener(x=6, config=config, reg=reg, mem=mem)
                buffer.append(ins)
            else:
                ins, config, reg, mem = ins_gener(x=9, config=config, reg=reg, mem=mem)
                buffer.append(ins)
        for i in range(config['label_num']):
            labels.append("label%d:\n" % i)
        for i in range(config['jump_num']):
            labels.append("jump%d:\n" % i)

        print(buffer)
        print(labels)
        random.shuffle(labels)
        random_insert_list(buffer, labels)

        # do init
        if len(init_asm) != 0:
            for j in init_asm:
                file.write(j)

        for j in buffer:
            file.write(j)


if __name__ == '__main__':
    run()
    