from argparse import ArgumentParser


def prepare_parser():
    parser = ArgumentParser(description="adaptable_command_generaotr")
    
    parser.add_argument("--test_size", default=300, type=int,
                        help="how many cmd in one asm")

    parser.add_argument("--init", default=True, type=bool,
                        help="decide whether init reg with not zero value")

    parser.add_argument("--bound", default=False, type=bool,
                        help="whether include bound-test")

    return vars(parser.parse_args())
