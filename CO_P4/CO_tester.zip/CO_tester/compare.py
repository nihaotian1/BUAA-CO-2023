# -*- coding:utf-8 -*-
import os

pathIsm = "D:\\CO\\CO_P4\\isim.log"
pathMars = "log.txt"

ise_log = []
mars_log = []

with open(pathMars, "r") as file:
    str = file.readline()
    while str is not None and str != "":
        if str[0] == "@":
            mars_log.append(str)
        str = file.readline()

with open(pathIsm, "r") as file:
    str = file.readline()
    while str is not None and str != "":
        if str[0] == "@":
            ise_log.append(str)
        str = file.readline()

print(len(mars_log))
print(len(ise_log))
length = min(len(mars_log), len(ise_log))

flag = 0
for i in range(length - 1):
    if ise_log[i] != mars_log[i]:
        print("We expect %s, but we got %s" % (mars_log[i], ise_log[i]))
        flag = 1
if flag == 0:
    print("we find no bug in this epoch!")
else:
    print("debug is needed!")
    print("our code.txt is:")
    with open("D:\\CO\\CO_P4\\CO_tester\\code.asm", "r") as file:
        print(file.read())
