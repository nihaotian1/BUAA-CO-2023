#!/bin/bash
python main.py
timeout 1s java -jar Mars_CO_v0.4.1.jar code.asm mc CompactLargeText coL1 ig > log.txt
java -jar Mars_CO_v0.4.1.jar code.asm mc CompactDataAtZero a dump .text HexText D:\\CO\\CO_P4\\code.txt
