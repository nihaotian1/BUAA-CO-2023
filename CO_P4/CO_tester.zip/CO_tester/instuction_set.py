# -*- coding:utf-8 -*-
import random


def add(reg):
    rs = random.randint(0, 31)
    rt = random.randint(0, 31)
    rd = random.randint(0, 31)
    ins = "add $%d, $%d, $%d\n" % (rd, rs, rt)
    if rd != 0:
        reg[rd] = (reg[rs] + reg[rt]) & (4294967296 - 1)
    return reg, ins


def sub(reg):
    rs = random.randint(0, 31)
    rt = random.randint(0, 31)
    rd = random.randint(0, 31)
    ins = "sub $%d, $%d, $%d\n" % (rd, rs, rt)
    if rd != 0:
        reg[rd] = (reg[rs] - reg[rt]) & (2147483648 - 1)
    return reg, ins


def ori(config, reg):
    if config['bound']:
        imm = random.randint(65530, 65535)
    else:
        imm = random.randint(0, 65535)
    rs = random.randint(0, 31)
    rt = random.randint(0, 31)
    imm = imm - imm % 4
    ins = "ori $%d, $%d, 0x%x\n" % (rt, rs, imm)  # require 0-ext, 0x0000_xxxx
    if rt != 0:
        reg[rt] = reg[rs] | (imm & (65536 - 1))
    return config, reg, ins


def lw(reg, mem):
    rs = random.randint(0, 31)
    rt = random.randint(0, 31)
    imm = random.randint(0, 12287)
    imm = imm - imm % 4
    imm = imm - reg[rs]
    if imm > 32767 or imm < -32768 or imm + reg[rs] > 0x0000_2fff or imm + reg[rs] < 0:
        ins = ""
    else:
        ins = "lw $%d, %d($%d)\n" % (rt, imm, rs)
        reg[rt] = mem[reg[rs]+imm]

    return reg, mem, ins


def sw(reg, mem):
    rs = random.randint(0, 31)
    rt = random.randint(0, 31)
    imm = random.randint(0, 12287)
    imm = imm - imm % 4
    imm = imm - reg[rs]
    if imm > 32767 or imm < -32768 or imm + reg[rs] > 0x0000_2fff or imm + reg[rs] < 0:
        ins = ""
    else:
        ins = "sw $%d, %d($%d)\n" % (rt, imm, rs)
        mem[reg[rs] + imm] = reg[rt]

    return reg, mem, ins


def beq(config):
    rs = random.randint(0, 31)
    rt = random.randint(0, 31)
    ins = "beq $%d, $%d, label%d\n" % (rs, rt, config['label_num'])
    config['label_num'] += 1
    return config, ins
    

def lui(config, reg):
    if config['bound']:
        imm = random.randint(65530, 65535)
    else:
        imm = random.randint(0, 65535)
    rt = random.randint(0, 31)
    ins = "lui $%d, 0x%x\n" % (rt, imm)
    if rt != 0:
        reg[rt] = imm << 16
    return config, reg, ins


def jal(config):
    ins = "jal jump%d\n" % config['jump_num']
    config['jump_num'] += 1
    return config, ins


def jr(config, reg):
    list = []
    for i in reg:
        if 0x3000 <= reg[i] <= 0x3300 and reg[i] % 4 == 0:
            list.append(i)

    if len(list) == 0:
        return config, reg, ""
    else:
        index = random.randint(0, len(list) - 1)
        rs = list[index]
        ins = "jr $%d\n" % rs
        return config, reg, ins


def nop():
    return "nop\n"
